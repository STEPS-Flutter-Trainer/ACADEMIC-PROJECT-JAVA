
		  function ValidateEmail()
		  {
		  sendInfo();
		  var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		  var email = document.form1.email.value;
		  //alert(email);
		  if(email.match(mailformat))
		  {
		  document.getElementById("mail").innerText = "   ";
		  return true;
		  }
		  else
		  {
		   document.form1.email.focus();  
		  return false;
		  }
		  }   
	  function submitCheck()
	  {
		  if(mailcheck()&&ValidateEmail())
			  {
			  return true;
			  }
		  else 
			  {
			  return false;
			  }  
	  }
		  var request;  
		  function sendInfo(){  
		  var email=document.form1.email.value;  
		  var url="emailfinder.jsp?email="+email;
		  if(window.XMLHttpRequest){  
		  request=new XMLHttpRequest();  
		  }  
		  else if(window.ActiveXObject){  
		  request=new ActiveXObject("Microsoft.XMLHTTP");  
		  }  
		  try{  
		  request.onreadystatechange=getInfo;  
		  request.open("GET",url,true);  
		  request.send();  
		  }catch(e){alert("Unable to connect to server");}  
		  }  
		  function getInfo(){  
		  if(request.readyState==4){  
		  var val=request.responseText;  
		  document.getElementById('mylocation').innerHTML=val;
		  }  
		  } 
		  function mailcheck()
		  { var availability=document.getElementById('check').value;
			  if(availability=="false")
				  {
				  return false;
				  }
			  else
				  {
				  return true;
				  }	  
		  }
