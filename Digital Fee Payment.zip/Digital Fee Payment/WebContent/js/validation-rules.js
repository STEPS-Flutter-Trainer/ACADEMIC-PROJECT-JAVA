
$().ready(function() {
		$("#regform").validate({
			ignore: ".ignore",
			rules: {
				school_name: {
					required : true,
					maxlength : 200
				},
				school_address_1: {
					required : true,
					maxlength : 100
				},
				school_address_2: {
					required : true,
					maxlength : 100
				},
				school_address_3: {
					required : false,
					maxlength : 100
				},
				school_pincode : {
					required : true,
					maxlength : 8
				},
				school_phone : {
					required : true,
					maxlength : 15
				},
				school_state: {
					required : true,
					maxlength : 40
				},
				school_password: {
					required: true,
					minlength: 8
				},
				school_password_confirm: {
					required: true,
					minlength: 8,
					equalTo: "#school_password"
				},
				school_apiloginid: {
					required: true,
					maxlength : 20
				},
				school_apiloginid_confirm: {
					required: true,
					maxlength : 20,
					equalTo: "#school_apiloginid"
				},
				school_transactionkey: {
					required: true,
					maxlength : 20
				},
				school_transactionkey_confirm: {
					required: true,
					maxlength : 20,
					equalTo: "#school_transactionkey"
				},
				hiddenRecaptcha: {
	                required:function () {
	                    if (grecaptcha.getResponse() == '') {
	                        return true;
	                    } else {
	                        return false;
	                    }
	                }
				},
				school_email: {
					required: true,
					maxlength : 255,
					email: true
				}
			},
			messages: {
				school_name: {
					required : "School name is required",
					maxlength : "School name must be under 200 characters"
				},
				school_address_1: {
					required : "School address is required",
					maxlength : "School address must be under 100 characters"
				},
				school_address_2: {
					required : "School address is required",
					maxlength : "School address must be under 100 characters"
				},
				school_address_3: {
					maxlength : "School address must be under 100 characters"
				},
				school_pincode : {
					required : "School pincode is required",
					maxlength : "School pincode must be under 8 characters"
				},
				school_phone : {
					required : "School phone is required",
					maxlength : "School phone must be under 15 characters"
				},
				school_state: {
					required : "School State is required",
					maxlength : "School state must be under 40 characters"
				},
				school_password: {
					required: "Please provide a password",
					minlength: "Your password must be at least 8 characters long"
				},
				school_password_confirm: {
					required: "Please provide a password",
					minlength: "Your password must be at least 8 characters long"
				},
				school_email: {
					required : "Email is required",
					maxlength : "Email must be under 255 characters"
				},
			}
			
		});
});
