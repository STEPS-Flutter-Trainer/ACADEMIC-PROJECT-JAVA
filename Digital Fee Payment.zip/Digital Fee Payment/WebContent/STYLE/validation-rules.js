
$().ready(function() {
		$("#ParentRegistration").validate({
			ignore: ".ignore",
			rules: {
				First_Name: "required",
				Last_Name: "required",
				Address_Line1: "required",
				Address_Line2: "required",
				Address_Line3 : "required",
				State : "required",
				Pincode: "required",
				Phone_Number: "required",
				Password: {
					required: true,
					minlength: 8
				},
				Confirm_Password: {
					required: true,
					minlength: 8,
					equalTo: "#Password"
				},
				
				hiddenRecaptcha: {
	                required:function () {
	                    if (grecaptcha.getResponse() == '') {
	                        return true;
	                    } else {
	                        return false;
	                    }
	                }
				},
				
			},
			messages: {
				First_Name: "Please enter First Name",
				Last_Name: "Please enter Last Name",
				Address_Line1: "Please enter  address",
				Address_Line2: "Please enter  address",
				Address_Line3 : "Please enter address",
				State : "Please enter state",
				Pincode: "Please enter Pin Code",
				Phone_Number: "Please enter phone number",
				Password: {
					required: "Please provide a password",
					minlength: "Your password must be at least 8 characters long"
				},
				Confirm_Password: {
					required: "Please provide a password",
					minlength: "Your password must be at least 8 characters long",
				},
				
			}
			
		});
});
