/*
SQLyog Community v13.1.2 (64 bit)
MySQL - 5.7.26 : Database - project
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`project` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `project`;

/*Table structure for table `address` */

DROP TABLE IF EXISTS `address`;

CREATE TABLE `address` (
  `Adrs_id` int(11) NOT NULL AUTO_INCREMENT,
  `Adrs_line1` varchar(100) NOT NULL,
  `Adrs_line2` varchar(100) NOT NULL,
  `Adrs_state` varchar(40) NOT NULL,
  `Adrs_pin` varchar(8) NOT NULL,
  `Adrs_type` varchar(2) DEFAULT NULL,
  `Adrs_status` int(1) DEFAULT NULL,
  `Adrs_line3` varchar(100) NOT NULL,
  PRIMARY KEY (`Adrs_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

/*Data for the table `address` */

insert  into `address`(`Adrs_id`,`Adrs_line1`,`Adrs_line2`,`Adrs_state`,`Adrs_pin`,`Adrs_type`,`Adrs_status`,`Adrs_line3`) values 
(1,'Puliyathu Parambil','House Nadavaramba P O','kerala','680661','p',1,'Thrissur'),
(2,'Pazhaniyil Parambil','House Nadavaramba P O','Kerala','680661','p',1,'Thrissur'),
(3,'Sanjay Resorts','Vivekananda Nagar','Kerala','695006','p',1,' Trivandrum'),
(4,'Venkatswamy naidu Road','Opp Harsha Hotel','Karnataka','560051','p',1,' Bangalore'),
(5,'No 52 MGR Street ','Ullagaram Nanganallur','Tamil Nadu','600061','p',1,' Kanchepuram'),
(6,'Nr RS Road','Irinjalakuda','Kerala','680121','s',1,'Thrissur'),
(7,'NR Church','Irinjalakuda','Kerala','680121','s',1,'Thrissur'),
(8,'Thriprayar RD','Irinjalakuda','Kerala','680121','s',1,'Thrissur'),
(9,'Tana','Irinjalakuda','Kerala','680121','s',1,'Thrissur'),
(10,'Tana','Irinjalakuda','Kerala','680121','s',1,'Thrissur'),
(11,'defad','defad','defad','defad','d',0,'defad'),
(12,'1','1','1','1','s',1,'1'),
(13,'DBHSS IJK','Nr IJK','Kerala','680121','s',1,'Thrissur'),
(16,'aswathi','janakiram apartment pallikunnu','kerala','670004','p',1,'kannur'),
(17,'','','','','p',1,'');

/*Table structure for table `login_table` */

DROP TABLE IF EXISTS `login_table`;

CREATE TABLE `login_table` (
  `Lo_id` int(10) NOT NULL AUTO_INCREMENT,
  `Lo_username` varchar(255) NOT NULL,
  `Lo_password` varchar(455) NOT NULL,
  `Lo_key` varchar(255) NOT NULL,
  `Lo_user_type` int(1) NOT NULL,
  `Lo_status` int(1) NOT NULL,
  PRIMARY KEY (`Lo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

/*Data for the table `login_table` */

insert  into `login_table`(`Lo_id`,`Lo_username`,`Lo_password`,`Lo_key`,`Lo_user_type`,`Lo_status`) values 
(2,'donbosco@mailinator.com','MTIzYTY1NGRjZjctMTU5MC00NzRiLWIzNmUtOTkzNTZmYmUzZTRh','a654dcf7-1590-474b-b36e-99356fbe3e4a',3,1),
(3,'stmarys@mailinator.com','MTIzMjY1ZDEyYTctZjg5Mi00OGE4LTk1MmMtM2YwYTkyNzI5ZDhl','265d12a7-f892-48a8-952c-3f0a92729d8e',3,0),
(4,'national@mailinator.com','MTIzYTY1NGRjZjctMTU5MC00NzRiLWIzNmUtOTkzNTZmYmUzZTRh','a654dcf7-1590-474b-b36e-99356fbe3e4a',3,1),
(5,'boys@mailinator.com','MTIzM2YxYjIwMTgtMWU1NC00NDU5LWFiNTgtMTE2NTAzNDM2YTQ4','3f1b2018-1e54-4459-ab58-116503436a48',3,1),
(6,'girls@mailinator.com','MTIzY2Q3OGQ1OGMtOTcyMS00ZGQzLThhZWUtNjY3NWQ5YjVhNTY3','cd78d58c-9721-4dd3-8aee-6675d9b5a567',3,1),
(7,'sathyajith@mailinator.com','MTIzNWUxMmU3ZmEtNGNkMS00YWMxLWFkNDYtNDRlNDNjZGUwN2M2','5e12e7fa-4cd1-4ac1-ad46-44e43cde07c6',4,1),
(8,'srijith@mailinator.com','MTIzMzdmZDQwZDQtNTQzYi00OWFiLThlNzUtZGM2NDYzNDFmODM2','37fd40d4-543b-49ab-8e75-dc646341f836',4,1),
(9,'anala@mailinator.com','MTIzMjk0ZjRiZWEtMTFkYi00ZTcxLWJmZjktZjFiZGM1YzUyMjRl','294f4bea-11db-4e71-bff9-f1bdc5c5224e',4,1),
(10,'varana@mailinator.com','MTIzOTQyMGM4MmEtMzQwMy00YWQ0LWFiYWYtMjExMzJiN2IwMDFi','9420c82a-3403-4ad4-abaf-21132b7b001b',4,1),
(11,'Ballari@mailinator.com','MTIzMjFlMmYzMjgtZDU3NC00MDUwLThlMmEtMGFjYjJlNDViZmE5','21e2f328-d574-4050-8e2a-0acb2e45bfa9',4,1),
(12,'defaultmail','default pass','default pass',0,0),
(15,'paulalexk@gmail.com','MTIzZWIzOGIyZDMtNGFjMS00ZTZjLWFmZTQtMTE1OWQ3MGU1MjQx','eb38b2d3-4ac1-4e6c-afe4-1159d70e5241',1,1),
(16,'sathyajithsps@gmail.com','MTIzYzYzOWE0ZjktNmFjZC00OGRlLWI0MmMtODViODk0MmYyMmVl','c639a4f9-6acd-48de-b42c-85b8942f22ee',2,1),
(17,'alex@mailinator.com','MTIzY2ZkNDhkNjItYzdlOC00MzBiLTkwYzctMzQ0YWJkZDEyNjI2','cfd48d62-c7e8-430b-90c7-344abdd12626',2,1),
(18,'bromistapayment@gmail.com','ZW5QRmFqWURjY2FkN2RiYS0xYzlmLTRjNmQtOWMwNy0wOTkyMzZiMTE5MDc=','ccad7dba-1c9f-4c6d-9c07-099236b11907',2,0),
(19,'donbosco12345@mailinator.com','MTIzNDU2NzhjZmFkZDhkMS0xZmMwLTRlNGEtYTQ4Yi1kMjQ0MTI0ZTZkN2E=','cfadd8d1-1fc0-4e4a-a48b-d244124e6d7a',3,1),
(22,'akhiltest@mailinator.com','MTIzNDU2Nzg5MzM0Mjg0MTgtYjMyZC00ZjI1LWE1NzgtZjdkY2QwNWFiNTg1','33428418-b32d-4f25-a578-f7dcd05ab585',4,1),
(23,'null','MWIwYWE3ZDUtZWEwOS00MTE2LTk0ODItZTMwMzA1YTA5NWQz','1b0aa7d5-ea09-4116-9482-e30305a095d3',4,1);


/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `Adm_id` int(11) NOT NULL AUTO_INCREMENT,
  `Adm_name` varchar(50) DEFAULT NULL,
  `Adm_contact` varchar(50) DEFAULT NULL,
  `Adm_mail` varchar(50) DEFAULT NULL,
  `Lo_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Adm_id`),
  KEY `Lo_id` (`Lo_id`),
  CONSTRAINT `admin_ibfk_1` FOREIGN KEY (`Lo_id`) REFERENCES `login_table` (`Lo_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `admin` */

insert  into `admin`(`Adm_id`,`Adm_name`,`Adm_contact`,`Adm_mail`,`Lo_id`) values 
(2,'alex k paul','+916282755405','paulalexk@gmail.com',15),
(3,'paul','6282755405','sathyajithsps@gmail.com',16),
(4,'pahr','+916282755405','alex@mailinator.com',17),
(5,'bromista',NULL,'bromistapayment@gmail.com',18);

/*Table structure for table `school` */

DROP TABLE IF EXISTS `school`;

CREATE TABLE `school` (
  `Sch_id` int(11) NOT NULL AUTO_INCREMENT,
  `Sch_name` varchar(200) NOT NULL,
  `Sch_contact` varchar(15) NOT NULL,
  `Sch_email` varchar(255) NOT NULL,
  `Email_status` int(10) NOT NULL,
  `Sch_api_loginid` varchar(40) NOT NULL,
  `Sch_api_trnkey` varchar(40) NOT NULL,
  `Sch_status` int(1) NOT NULL,
  `Adrs_id` int(11) NOT NULL,
  `Lo_id` int(11) NOT NULL,
  PRIMARY KEY (`Sch_id`),
  KEY `Lo_id` (`Lo_id`),
  KEY `Adrs_id` (`Adrs_id`),
  CONSTRAINT `school_ibfk_1` FOREIGN KEY (`Lo_id`) REFERENCES `login_table` (`Lo_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `school_ibfk_2` FOREIGN KEY (`Adrs_id`) REFERENCES `address` (`Adrs_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

/*Data for the table `school` */

insert  into `school`(`Sch_id`,`Sch_name`,`Sch_contact`,`Sch_email`,`Email_status`,`Sch_api_loginid`,`Sch_api_trnkey`,`Sch_status`,`Adrs_id`,`Lo_id`) values 
(5,'Don Bosco HSS','9495883356','donbosco@mailinator.com',1,'apiloginid01','transkey01',1,6,2),
(6,'ST Marys HSS','8547927856','stmarys@mailinator.com',1,'apiloginid02','transkey02',1,7,3),
(7,'National HSS','8289949832','national@mailinator.com',1,'apiloginid03','transkey03',1,8,4),
(8,'Boys HSS','9400529832','boys@mailinator.com',1,'apiloginid04','transkey04',1,9,5),
(9,'Girls HSS','9497068318','girls@mailinator.com',1,'apiloginid05','transkey05',1,10,6),
(11,'Don Bosco','9495883356','donbosco12345@mailinator.com',1,'7KL92hSy82B','3AseB444549xKbCS',1,13,19);

/*Table structure for table `parent` */

DROP TABLE IF EXISTS `parent`;

CREATE TABLE `parent` (
  `Par_id` int(11) NOT NULL AUTO_INCREMENT,
  `Par_name` varchar(30) NOT NULL,
  `Par_email` varchar(30) NOT NULL,
  `Par_phone` varchar(15) NOT NULL,
  `Par_status` int(11) NOT NULL,
  `Adrs_id` int(11) NOT NULL,
  `Lo_id` int(11) NOT NULL,
  PRIMARY KEY (`Par_id`),
  KEY `Adrs_id` (`Adrs_id`),
  KEY `Lo_id` (`Lo_id`),
  CONSTRAINT `parent_ibfk_1` FOREIGN KEY (`Adrs_id`) REFERENCES `address` (`Adrs_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `parent_ibfk_2` FOREIGN KEY (`Lo_id`) REFERENCES `login_table` (`Lo_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `parent` */

insert  into `parent`(`Par_id`,`Par_name`,`Par_email`,`Par_phone`,`Par_status`,`Adrs_id`,`Lo_id`) values 
(2,'Sathyajith P S','sathyajith@mailinator.com','8289949832',1,1,7),
(3,'Srijith P S','srijith@mailinator.com','8289949832',1,2,8),
(4,'Anala Gopal','anala@mailinator.com','8289949832',1,3,9),
(5,'Varana  Chawla','varana@mailinator.com','8289949832',1,4,10),
(6,'Ballari  Kurup','Ballari@mailinator.com','8289949832',1,5,11),
(8,'Parent Not signed up','Parent Email not found','phone',0,11,12),
(9,'akhil k','akhiltest@mailinator.com','9895088750',1,16,22),
(10,' ','null','',1,17,23);


/*Table structure for table `customer_profiles` */

DROP TABLE IF EXISTS `customer_profiles`;

CREATE TABLE `customer_profiles` (
  `Sch_id` int(11) DEFAULT NULL,
  `Cp_id` int(11) NOT NULL AUTO_INCREMENT,
  `Cp_Cpid` int(11) NOT NULL,
  `Cp_status` int(11) NOT NULL,
  `Par_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Cp_id`),
  KEY `Sch_id` (`Sch_id`),
  KEY `Par_id` (`Par_id`),
  CONSTRAINT `customer_profiles_ibfk_1` FOREIGN KEY (`Sch_id`) REFERENCES `school` (`Sch_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `customer_profiles_ibfk_2` FOREIGN KEY (`Par_id`) REFERENCES `parent` (`Par_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

/*Data for the table `customer_profiles` */

insert  into `customer_profiles`(`Sch_id`,`Cp_id`,`Cp_Cpid`,`Cp_status`,`Par_id`) values 
(11,20,1920333009,1,9);

/*Table structure for table `student` */

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `Student_pid` int(11) NOT NULL AUTO_INCREMENT,
  `Student_id` int(11) NOT NULL,
  `Student_name` varchar(50) NOT NULL,
  `Student_course` varchar(30) NOT NULL,
  `Student_Email` varchar(25) NOT NULL,
  `Student_status` int(1) NOT NULL,
  `Sch_id` int(11) NOT NULL,
  `Par_id` int(11) NOT NULL,
  PRIMARY KEY (`Student_pid`),
  KEY `Par_id` (`Par_id`),
  KEY `Sch_id` (`Sch_id`),
  CONSTRAINT `student_ibfk_1` FOREIGN KEY (`Par_id`) REFERENCES `parent` (`Par_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `student_ibfk_2` FOREIGN KEY (`Sch_id`) REFERENCES `school` (`Sch_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=latin1;

/*Data for the table `student` */

insert  into `student`(`Student_pid`,`Student_id`,`Student_name`,`Student_course`,`Student_Email`,`Student_status`,`Sch_id`,`Par_id`) values 
(48,1,'Jason','Civil','sathyajith@mailinator.com',0,5,2),
(49,2,'MJ','Civil','sathyajith@mailinator.com',0,5,2),
(50,1,'Rebbeca Duffie','Civil','srijith@mailinator.com',1,8,3),
(51,1,'Summer Hyche','Civil','varana@mailinator.com',1,9,5),
(52,1,'John wick','Mech','sathyajith@mailinator.com',1,5,2),
(53,3,'Jimmy s','Civil','sathyajith@mailinator.com',1,5,2),
(54,1,'Moriah Selander','Mech','anala@mailinator.com',1,8,4),
(55,1,'Herlinda Magness','Mech','anala@mailinator.com',1,9,4),
(56,1,'Jackie','CSE','srijith@mailinator.com',1,5,3),
(57,2,'Neal','CS','sathyajith@mailinator.com',1,5,2),
(58,3,'NIki Forbusss','CS','sathyajith@mailinator.com',2,5,2),
(59,1,'Stacia Harber  ','Civil','Ballari@mailinator.com',1,6,6),
(60,2,'Kristine Morais  ','Civil','sathyajith@mailinator.com',1,6,2),
(61,3,'Travis Padula  ','Civil','Ballari@mailinator.com',1,6,6),
(62,2,'Johnathan Thode  ','Civil','sathyajith@mailinator.com',1,9,2),
(63,1,'Ninfa West  ','Mech','varana@mailinator.com',1,6,5),
(64,2,'Weldon Biggs  ','Mech','Ballari@mailinator.com',1,6,6),
(65,3,'Delisa Millender  ','Mech','srijith@mailinator.com',1,6,3),
(66,2,'Robbin Flavors  ','Mech','anala@mailinator.com',1,8,4),
(67,1,'Hoyt Nickelson  ','CS','Ballari@mailinator.com',1,6,6),
(68,2,'Bula Cleavenger  ','CS','sathyajith@mailinator.com',1,6,2),
(69,3,'Melia Yuan  ','CS','anala@mailinator.com',1,6,4),
(70,1,'Sharlene Heidler  ','CS','Ballari@mailinator.com',1,8,6),
(71,1,'Samantha Berta','Mech','sathyajith@mailinator.com',1,7,2),
(72,2,'Venita Gatlin  ','Mech','Ballari@mailinator.com',1,7,6),
(73,3,'Romona Levier  ','Mech','anala@mailinator.com',1,7,4),
(74,3,'Juliet Divis  ','Mech','varana@mailinator.com',1,8,5),
(75,1,'Otto Sharpless  ','CS','varana@mailinator.com',1,7,5),
(76,2,'Jeanne Mathison  ','CS','varana@mailinator.com',1,7,5),
(77,2,'Nadine Demery ','CS','anala@mailinator.com',1,8,4),
(89,1,'akhil test','2','akhiltest@mailinator.com',1,11,9),
(91,1,'akhil test 222','mech','akhiltest@mailinator.com',1,11,9);


/*Table structure for table `fee` */

DROP TABLE IF EXISTS `fee`;

CREATE TABLE `fee` (
  `fee_id` int(11) NOT NULL AUTO_INCREMENT,
  `fee_amount` float NOT NULL DEFAULT '0',
  `fee_due` date NOT NULL DEFAULT '2019-01-01',
  `Student_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`fee_id`),
  KEY `Student_id` (`Student_id`),
  CONSTRAINT `fee_ibfk_1` FOREIGN KEY (`Student_id`) REFERENCES `student` (`Student_pid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=latin1;

/*Data for the table `fee` */

insert  into `fee`(`fee_id`,`fee_amount`,`fee_due`,`Student_id`) values 
(47,599,'2019-07-01',48),
(48,699,'2019-07-04',49),
(49,500,'2019-09-26',50),
(50,1000,'2019-07-30',51),
(51,799,'2019-12-31',52),
(52,999,'2019-07-07',53),
(53,500,'2019-07-30',54),
(54,500,'2019-09-26',55),
(55,499,'2019-12-31',56),
(56,399,'2019-12-30',57),
(57,299,'2019-11-30',58),
(58,500,'2019-09-12',59),
(59,800,'2019-07-30',60),
(60,500,'2019-07-30',61),
(61,500,'2019-09-12',62),
(62,1000,'2019-08-17',63),
(63,500,'2019-09-12',64),
(64,1000,'2019-09-26',65),
(65,2000,'2019-09-12',66),
(66,2000,'2019-09-26',67),
(67,800,'2019-08-17',68),
(68,2000,'2019-07-30',69),
(69,800,'2019-08-17',70),
(70,2110,'2019-08-17',71),
(71,1000,'2019-09-26',72),
(72,2000,'2019-07-30',73),
(73,800,'2019-09-26',74),
(74,1000,'2019-07-30',75),
(75,800,'2019-09-26',76),
(76,1000,'2019-09-26',77),
(88,8000,'2019-08-02',89),
(90,1099,'2019-10-23',91);

/*Table structure for table `issue` */

DROP TABLE IF EXISTS `issue`;

CREATE TABLE `issue` (
  `issue_id` int(11) NOT NULL AUTO_INCREMENT,
  `issue_raiser` varchar(255) DEFAULT NULL,
  `issue_title` varchar(50) DEFAULT NULL,
  `issue_content` varchar(600) DEFAULT NULL,
  `issue_status` int(1) DEFAULT '0',
  PRIMARY KEY (`issue_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `issue` */

insert  into `issue`(`issue_id`,`issue_raiser`,`issue_title`,`issue_content`,`issue_status`) values 
(1,'donbosco@mailinator.com','Bug','There is a bug',1),
(2,'donbosco@mailinator.com','Custom ','Custom Issue',0),
(3,'donbosco@mailinator.com','Custom2','Custom Issue 2',1),
(5,'boys@mailinator.com','Feature Request','new feature',0),
(6,'donbosco@mailinator.com','Dispute','Sample Dispute',0),
(7,'donbosco@mailinator.com','Bug','New bug',0),
(8,'donbosco@mailinator.com','Dispute','Sample',0),
(9,'donbosco@mailinator.com','New Issue','Sample',0),
(10,'donbosco@mailinator.com','new issue for testing','bla bla',0);


/*Table structure for table `otp` */

DROP TABLE IF EXISTS `otp`;

CREATE TABLE `otp` (
  `otp_id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(30) DEFAULT NULL,
  `gen_otp` int(11) DEFAULT NULL,
  PRIMARY KEY (`otp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `otp` */

insert  into `otp`(`otp_id`,`number`,`gen_otp`) values 
(1,'+916282755405',6398),
(2,'+916282755405',6448),
(3,'+916282755405',408),
(4,'+916282755405',9245),
(5,'+916282755405',6634);


/*Table structure for table `payment_profiles` */

DROP TABLE IF EXISTS `payment_profiles`;

CREATE TABLE `payment_profiles` (
  `Pp_id` int(11) NOT NULL AUTO_INCREMENT,
  `Pp_ppid` int(11) NOT NULL,
  `Pp_ccno` int(11) NOT NULL,
  `Pp_status` int(1) NOT NULL,
  `Cp_id` int(11) NOT NULL,
  PRIMARY KEY (`Pp_id`),
  KEY `Cp_id` (`Cp_id`),
  CONSTRAINT `payment_profiles_ibfk_1` FOREIGN KEY (`Cp_id`) REFERENCES `customer_profiles` (`Cp_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `payment_profiles` */

insert  into `payment_profiles`(`Pp_id`,`Pp_ppid`,`Pp_ccno`,`Pp_status`,`Cp_id`) values 
(2,1833303604,1111,1,20);

/*Table structure for table `sch_temp` */

DROP TABLE IF EXISTS `sch_temp`;

CREATE TABLE `sch_temp` (
  `schid` int(11) NOT NULL AUTO_INCREMENT,
  `schname` varchar(20) DEFAULT NULL,
  `schmail` varchar(100) DEFAULT NULL,
  `schstatus` int(1) DEFAULT '0',
  PRIMARY KEY (`schid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `sch_temp` */

insert  into `sch_temp`(`schid`,`schname`,`schmail`,`schstatus`) values 
(1,'Don Bosco','donbosco@mailinator.com',1),
(3,'don','donbosco12345@mailinator.com',1),
(5,NULL,NULL,0);


/*Table structure for table `transaction` */

DROP TABLE IF EXISTS `transaction`;

CREATE TABLE `transaction` (
  `Trans_id` int(11) NOT NULL AUTO_INCREMENT,
  `Trans_date` date NOT NULL,
  `Trans_time` time NOT NULL,
  `Trans_status` int(11) NOT NULL,
  `Trans_response` varchar(500) NOT NULL,
  `fee_amount` double NOT NULL,
  `fee_due` date NOT NULL,
  `student_id` int(11) NOT NULL,
  `pp_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Trans_id`),
  KEY `transaction_ibfk_3` (`student_id`),
  KEY `pp_id` (`pp_id`),
  CONSTRAINT `transaction_ibfk_3` FOREIGN KEY (`student_id`) REFERENCES `student` (`Student_pid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `transaction_ibfk_4` FOREIGN KEY (`pp_id`) REFERENCES `payment_profiles` (`Pp_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `transaction` */

insert  into `transaction`(`Trans_id`,`Trans_date`,`Trans_time`,`Trans_status`,`Trans_response`,`fee_amount`,`fee_due`,`student_id`,`pp_id`) values 
(1,'2019-08-02','13:11:09',1,'1',8000,'2019-08-02',89,NULL),
(2,'2019-08-02','14:13:01',1,'1',1099,'2019-10-23',91,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
