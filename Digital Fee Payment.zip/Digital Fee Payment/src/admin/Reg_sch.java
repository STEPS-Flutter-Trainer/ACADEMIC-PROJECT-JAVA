package admin;




import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Message.RecipientType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class Reg_sch {
	public void sendConfirmation(String name,String mail) throws Exception, MessagingException
	{
		System.out.println("in mail"+name+" email in mail"+mail);
	try {
			
			  final String user ="bromistapayment@gmail.com";//from email
			  final String pass="BromistaPayment@2019";//from email password
			  
			  
			  
				Properties props = System.getProperties();  
				props.setProperty("proxySet", "true");
				//props.setProperty("SocksProxyHost", "192.168.155.1");
				//props.setProperty("SocksProxyPort", "25");
				props.setProperty("mail.smtp.host","smtp.gmail.com");
				props.put("mail.smtp.socketFactory.port", "465");
				//props.setProperty("mail.smtp.starttls.enable", "true");
				props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
				props.put("mail.smtp.socketFactory.fallback", "false");
				//props.put("mail.smtp.port", "465");
				props.put("mail.smtp.auth", "true"); 
			
			  Session session = Session.getDefaultInstance(props, new
			  javax.mail.Authenticator() { protected PasswordAuthentication
			  getPasswordAuthentication() { return new PasswordAuthentication(user,pass); }
			  });
			 	 
		String sm="Registration complete DigitalPayment.com";		
		MimeMessage message = new MimeMessage(session);
		message.setFrom(new InternetAddress(user));
		message.setRecipients(RecipientType.TO,mail);
		System.out.println("mail to send"+mail);
		message.setSubject(sm);
		BodyPart messageBodyPart1 = new MimeBodyPart();    	        
		messageBodyPart1.setContent( "<table><tr><td>Hi&nbsp;"+name+",</td><td></td></tr><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td colspan='2'><font color='red'>Congratulations!!!</font><br><br></td></tr>" ,"text/html; charset=utf-8" );
		Multipart multipart = new MimeMultipart();  
		multipart.addBodyPart(messageBodyPart1);  
		System.out.println("Inside Mail");
		/*BodyPart messageBodyPart2 = new MimeBodyPart();    	        
		messageBodyPart2.setContent( "<table><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td colspan='2'>Your school has been added to the digital payment system by the admin wtih  <br>Username : "+name+"<br>Email :"+email+" .please click the below link to complete the registration with the company <br> </td></tr>" ,"text/html; charset=utf-8" );
		multipart.addBodyPart(messageBodyPart2);  */
		BodyPart messageBodyPart3 = new MimeBodyPart();    	        
		messageBodyPart3.setContent("Your school has been added to the digital payment system by the admin wtih  <br>Username : "+name+"<br>Email :"+mail+"<br>"+ " please click the below link to complete the registration with the company <br> "+ "URL:<a href='http://localhost:8080/Digital_Fee_Payment/school_register.jsp?mail="+mail+"'> http://localhost:8080/Digital_Fee_Payment/register.jsp</a><br><br>Thanking You,<br>admin" ,"text/html; charset=utf-8" );
		multipart.addBodyPart(messageBodyPart3);  
		message.setContent(multipart );           			    
		Transport.send(message);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}
