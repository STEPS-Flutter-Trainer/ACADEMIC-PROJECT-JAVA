package admin;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import admin.Dbb;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



/**
 * Servlet implementation class otp_check
 */
@WebServlet("/otp_check")
public class otp_check extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
     * @see HttpServlet#HttpServlet()
     */
    public otp_check() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		
		try{
			 HttpSession sess= request.getSession();
			 String email=(String)sess.getAttribute("email");
			 String phoneno=(String)sess.getAttribute("phone");
			 System.out.println("email in otp check"+email);
			/* String gen_otp = Verify_otpSimple.sotp;
			 System.out.println("gnerated otp"+gen_otp);*/
			 String f_otp= request.getParameter("otps");
			 //String ph=request.getParameter("phno"); 
			 System.out.println("form otp"+f_otp);
			 Dbb ob=new Dbb();
			 
			 
			//FETCHING OTP ID FROM OTP TABLE
			 String gen_otp=null;
			 String qu="select gen_otp from otp where number=? ";
			 PreparedStatement ps2=null;
			 ps2=ob.getPreparedstatement(qu);
			 ps2.setString(1, phoneno);
			 ResultSet rs=ps2.executeQuery();
			 while(rs.next()){
			 	 gen_otp=rs.getString(1);
			 	 System.out.println("gen otp"+gen_otp);
			 	
			 	
			 }
			
			 if(gen_otp.equalsIgnoreCase(f_otp))
			 
			 
			 
			{
				
				 String qry = "UPDATE admin SET adm_contact = ? where Adm_mail = ?";
				 
				 
				 
				 PreparedStatement ps=null;
				 ps =ob.getPreparedstatement(qry);
			
				 ps.setString(1,phoneno);
				 ps.setString(2,email);
				


				 int status=ps.executeUpdate();  
				 System.out.println("status on otp check1 is"+status);
				 
				/*//FETCHING LOGIN ID FROM LOGIN TABLE
				 int Lo_status=0;
				 String qu="select Lo_status from login_table where Lo_username=?";
				 PreparedStatement ps2=null;
				 ps2=ob.getPreparedstatement(qu);
				 ps2.setString(1, email);
				 ResultSet rs=ps2.executeUpdate();
				 while(rs.next()){
				 	Lo_id=rs.getInt(1);
				 	
				 }*/
				 
				 
				 
					
			    	String qr = "UPDATE Login_table SET Lo_status = ? where Lo_username = ?";
					 
					 
					 
					 PreparedStatement ps3=null;
					 ps3 =ob.getPreparedstatement(qr);
				
				ps3.setInt(1, 1);
				ps3.setString(2, email);


					 int statuslo=ps3.executeUpdate(); 
					 System.out.println("status on otp check2 is"+statuslo);

			    if(status==1 && statuslo==1){  
			    	
			    
			    	
				 System.out.println("Registration sucessful.");  
				
				 
				 }  
				 else  
				 {  
				System.out.println("registration error");  
				 
				 
				 }
				 
	 
			 RequestDispatcher req = request.getRequestDispatcher("index.jsp");
			 req.forward(request,response);
			
			 }else{
				 RequestDispatcher req = request.getRequestDispatcher("verify.jsp");
				 req.forward(request,response);
			 }}
			 catch(Exception e){
				 e.printStackTrace();
			 }

	}

}
