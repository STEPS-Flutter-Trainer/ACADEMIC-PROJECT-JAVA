package admin;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;
 
public class Validation {
 
public static String validate(String userName,String password) throws Exception
{

 Dbb dbb = new Dbb();
 String userNameDB = "";
 String passwordDB = "";
 String key = "";
 String query = "select * from login_table where Lo_username=?";
 PreparedStatement query_login = null;
 ResultSet resultSet=null;
 
 try
 {	 
 query_login = dbb.getPreparedstatement(query);
 query_login.setString(1,userName);
 resultSet = query_login.executeQuery();
 while(resultSet.next())
 {
 userNameDB = resultSet.getString("Lo_username");

 passwordDB = resultSet.getString("Lo_password");
 int roleDB = resultSet.getInt("Lo_user_type");

 int statusDB=resultSet.getInt("Lo_status");
 key        = resultSet.getString("Lo_key");
 String i= password + key;
 password=Base64.getEncoder().encodeToString(i.getBytes("utf-8"));

 if(userName.equals(userNameDB) && password.equals(passwordDB) && roleDB == 1 && statusDB==1)
 return "superadmin";
 else if(userName.equals(userNameDB) && password.equals(passwordDB) && roleDB == 2 && statusDB==1)
 return "admin";
 else if(userName.equals(userNameDB) && password.equals(passwordDB) && roleDB == 3)
 return "school";
 else if(userName.equals(userNameDB) && password.equals(passwordDB) && roleDB == 4)
 return "parent";
 }
 }
 catch(SQLException e)
 {
 e.printStackTrace();
 }
 return "your account is not activated or Invalid user credentials";
}
}