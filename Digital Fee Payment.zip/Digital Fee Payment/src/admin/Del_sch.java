package admin;

import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Message.RecipientType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class Del_sch {

	public void sendConfirmation(String emails,String msgs ) throws Exception, MessagingException
	{
		System.out.println("in mail"+emails+" "+msgs);
	try {
			
			  final String user ="bromistapayment@gmail.com";//from email
			  final String pass="BromistaPayment@2019";//from email password
			  
			  
				Properties props = System.getProperties();  
				props.setProperty("proxySet", "true");
				//props.setProperty("SocksProxyHost", "192.168.155.1");
				//props.setProperty("SocksProxyPort", "25");
				props.setProperty("mail.smtp.host","smtp.gmail.com");
				props.put("mail.smtp.socketFactory.port", "465");
				//props.setProperty("mail.smtp.starttls.enable", "true");
				props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
				props.put("mail.smtp.socketFactory.fallback", "false");
				//props.put("mail.smtp.port", "465");
				props.put("mail.smtp.auth", "true"); 
			
			  Session session = Session.getDefaultInstance(props, new
			  javax.mail.Authenticator() { protected PasswordAuthentication
			  getPasswordAuthentication() { return new PasswordAuthentication(user,pass); }
			  });
			 
			 
			
		MimeMessage message = new MimeMessage(session);
		message.setFrom(new InternetAddress(user));
		message.setRecipients(RecipientType.TO,emails);
		
		BodyPart messageBodyPart1 = new MimeBodyPart();    	        
		messageBodyPart1.setContent( "<table><tr><td>Hi&nbsp;"+emails+",</td><td></td></tr><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td colspan='2'><font color='red'>Your account has been deactivated!!!</font><br><br></td></tr>" ,"text/html; charset=utf-8" );
		Multipart multipart = new MimeMultipart();  
		multipart.addBodyPart(messageBodyPart1);  
		System.out.println("Inside Mail");
		BodyPart messageBodyPart2 = new MimeBodyPart();    	        
		messageBodyPart2.setContent( "<table><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td colspan='2'>Your account with Username : "+emails+" has been deactivated due to the following reason<br>"+msgs+"<br> </td></tr>" ,"text/html; charset=utf-8" );
		multipart.addBodyPart(messageBodyPart2);  
		message.setContent(multipart );           			    
		Transport.send(message);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}
