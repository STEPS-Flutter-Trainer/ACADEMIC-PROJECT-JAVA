package admin;

import com.twilio.sdk.TwilioRestClient;
import com.twilio.sdk.TwilioRestException;
import com.twilio.sdk.resource.factory.MessageFactory;
import com.twilio.sdk.resource.instance.Message;

import org.apache.http.HttpHost;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;

import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

public class verify_otp {

    // Find your Account Sid and Token at twilio.com/console
    public static final String  ACCOUNT_SID = "AC9e7d32e2e14e6f862986e9dc731c1ce6";
    public static final String  AUTH_TOKEN = "97fce0e45a318fcef229d8f3c5159c6c";
    public static final String  PROXY_ADDRESS = "202.146.192.174";
   public static final int     PROXY_PORT = 8080;
    public static final String  PROXY_USER = "sruthy_jtnr";
    public static final String  PROXY_PASSWORD = "a3szdx3ws";

    public static void main(String[] args) {

        //Set up Proxy host
        HttpHost proxy = new HttpHost(PROXY_ADDRESS, PROXY_PORT);
        DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);

        //Set up Proxy user credentials
        CredentialsProvider credsProvider = new BasicCredentialsProvider();
        credsProvider.setCredentials(
                new AuthScope(PROXY_ADDRESS, PROXY_PORT), 
                new UsernamePasswordCredentials(PROXY_USER, PROXY_PASSWORD));

        //Set up Twilio user credentials
        credsProvider.setCredentials(
                new AuthScope("api.twilio.com", 443), 
                new UsernamePasswordCredentials(ACCOUNT_SID, AUTH_TOKEN));

        //Set up HttpClient with proxy and credentials
        CloseableHttpClient httpClient = HttpClients.custom()
                .setRoutePlanner(routePlanner)
                .setDefaultCredentialsProvider(credsProvider)
                .build();


        TwilioRestClient client = new TwilioRestClient(ACCOUNT_SID, AUTH_TOKEN); 
        client.setHttpclient(httpClient);


        // Build a filter for the MessageList
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("Body", "Your OTP for Registering Company.com"));
        params.add(new BasicNameValuePair("To", "+919072272816"));
        params.add(new BasicNameValuePair("From", "+12054319926"));

        MessageFactory messageFactory = client.getAccount().getMessageFactory();

        try {
            Message message;
            message = messageFactory.create(params);
            System.out.println(message.getSid());

        } catch (TwilioRestException e) {
            System.out.println(e.getErrorCode());
            System.out.println(e.getErrorMessage());
            e.printStackTrace();
        }

    }

}