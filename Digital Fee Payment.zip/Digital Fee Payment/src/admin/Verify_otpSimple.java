package admin;



	import java.util.Random;

// Install the Java helper library from twilio.com/docs/java/install

	import com.twilio.Twilio;
	import com.twilio.rest.api.v2010.account.Message;
	

	public class Verify_otpSimple {
	    // Find your Account Sid and Token at twilio.com/console
	    // DANGER! This is insecure. See http://twil.io/secure
	    public static final String ACCOUNT_SID = "AC9e7d32e2e14e6f862986e9dc731c1ce6";
	    public static final String AUTH_TOKEN = "97fce0e45a318fcef229d8f3c5159c6c";
	    public static String sotp="";
	    
	    public static String getNum(String phno) {
	    	 Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
	    	 
	    	 String numbers = "0123456789";

		        // Using random method
		        Random rndm_method = new Random();

		        char[] otp = new char[4];

		        for (int i = 0; i < 4; i++)
		        {
		            // Use of charAt() method : to get character value
		            // Use of nextInt() as it is scanning the value as int
		            otp[i] =
		            numbers.charAt(rndm_method.nextInt(numbers.length()));
		        }
		        System.out.println(otp);
		        sotp=String.valueOf(otp);
		        
		        System.out.println(sotp);
		        Message message = Message.creator( new com.twilio.type.PhoneNumber(phno),new com.twilio.type.PhoneNumber("+12054319926"),sotp).create();

		        System.out.println(message.getSid());
		        return sotp;
		        
		      
		        
	    	
	    }

	    
	}

