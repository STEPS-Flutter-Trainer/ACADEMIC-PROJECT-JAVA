package mail;

import java.sql.*;
import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Message.RecipientType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import dB.Dbb;

public class Mail {
	public static void sendParentMail(String email,String student,int id) throws Exception, MessagingException
	{
		Dbb db = new Dbb();
		String sql = "SELECT Par_email,Par_status FROM parent WHERE Par_email=?";
		PreparedStatement parent_mail_fetch = db.getPreparedstatement(sql);
		parent_mail_fetch.setString(1,email);
		ResultSet retrieved_parent_data = parent_mail_fetch.executeQuery();
		 if (retrieved_parent_data.next() == false) {
			/* System.out.println("User Does not exist, sending signup mail."); */
		        try {
					
					  final String user ="bromistapayment@gmail.com";//from email
					  final String pass="BromistaPayment@2019";//from email password
					  
					  
						Properties props = System.getProperties();  
						props.setProperty("proxySet", "true");
						//props.setProperty("SocksProxyHost", "192.168.155.1");
						//props.setProperty("SocksProxyPort", "25");
						props.setProperty("mail.smtp.host","smtp.gmail.com");
						props.put("mail.smtp.socketFactory.port", "465");
						//props.setProperty("mail.smtp.starttls.enable", "true");
						props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
						props.put("mail.smtp.socketFactory.fallback", "false");
						//props.put("mail.smtp.port", "465");
						props.put("mail.smtp.auth", "true");  
					
					
					  Session session = Session.getDefaultInstance(props, new
					  javax.mail.Authenticator() { protected PasswordAuthentication
					  getPasswordAuthentication() { return new PasswordAuthentication(user,pass); }
					  });
					 
					 
				String mail_header="Parent Portal Signup Mail";		
				MimeMessage message = new MimeMessage(session);
				message.setFrom(new InternetAddress(user));
				message.setRecipients(RecipientType.TO,email);
				message.setSubject(mail_header);
				BodyPart messageBodyPart1 = new MimeBodyPart();    	        
				messageBodyPart1.setContent( "<table><tr><td>Hi&nbsp;"+email+",</td><td></td></tr><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td colspan='2'><font color='black'>Signup mail</font><br><br></td></tr>" ,"text/html; charset=utf-8" );
				Multipart multipart = new MimeMultipart();  
				multipart.addBodyPart(messageBodyPart1);  
				BodyPart messageBodyPart2 = new MimeBodyPart();    	        
				messageBodyPart2.setContent( "<table><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td colspan='2'>Signup to the parent portal using the following link. <br><br></td></tr>" ,"text/html; charset=utf-8" );
				multipart.addBodyPart(messageBodyPart2);  
				BodyPart messageBodyPart3 = new MimeBodyPart();    	        
				//messageBodyPart3.setContent( "<table><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td colspan='2'><a href='http://localhost:25697/USPS_Shipping_Label_08-01-2014/confirm.jsp?email="+email+"'> http://localhost:25697/USPS_Shipping_Label_08-01-2014/confirm.jsp?email="+email+"</a><br><br></td></tr><tr><td colspan='2'>Thanking You</td></tr>" ,"text/html; charset=utf-8" );
				messageBodyPart3.setContent( "<table><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td colspan='2'><a href='http://localhost:8080/Digital_Fee_Payment/Parent_Registration.jsp?email="+email+"&sid="+id+"'>Click here to register to the parent portal.</a><br><br></td></tr><tr><td colspan='2'>Thanking You</td></tr>" ,"text/html; charset=utf-8" );
				multipart.addBodyPart(messageBodyPart3);  
				message.setContent(multipart );           			    
				Transport.send(message);
			} catch (Exception e) {
				
				e.printStackTrace();
			}
		      } else {

		    	  try {
						
					  final String user ="bromistapayment@gmail.com";//from email
					  final String pass="BromistaPayment@2019";//from email password
					  
					  
						Properties props = System.getProperties();  
						props.setProperty("proxySet", "true");
						//props.setProperty("SocksProxyHost", "192.168.155.1");
						//props.setProperty("SocksProxyPort", "25");
						props.setProperty("mail.smtp.host","smtp.gmail.com");
						props.put("mail.smtp.socketFactory.port", "465");
						//props.setProperty("mail.smtp.starttls.enable", "true");
						props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
						props.put("mail.smtp.socketFactory.fallback", "false");
						//props.put("mail.smtp.port", "465");
						props.put("mail.smtp.auth", "true");  
					
					
					  Session session = Session.getDefaultInstance(props, new
					  javax.mail.Authenticator() { protected PasswordAuthentication
					  getPasswordAuthentication() { return new PasswordAuthentication(user,pass); }
					  });
					 
					 
				String mail_header="New Student : " + student + " has been added to your parent portal";		
				MimeMessage message = new MimeMessage(session);
				message.setFrom(new InternetAddress(user));
				message.setRecipients(RecipientType.TO,email);
				message.setSubject(mail_header);
				BodyPart messageBodyPart1 = new MimeBodyPart();    	        
				messageBodyPart1.setContent( "<table><tr><td>Hi&nbsp;"+email+",</td><td></td></tr><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td colspan='2'><font color='black'>Signup mail</font><br><br></td></tr>" ,"text/html; charset=utf-8" );
				Multipart multipart = new MimeMultipart();  
				multipart.addBodyPart(messageBodyPart1);  
				BodyPart messageBodyPart2 = new MimeBodyPart();    	        
				messageBodyPart2.setContent( "<table><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td colspan='2'>Click the below link to Confirm if  "+student + "is your child. Ignore this message otherwise. <br><br></td></tr>" ,"text/html; charset=utf-8" );
				multipart.addBodyPart(messageBodyPart2);  
				BodyPart messageBodyPart3 = new MimeBodyPart();    	        
				
				messageBodyPart3.setContent( "<table><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td></td><td></td></tr><tr><td colspan='2'><a href='http://localhost:8080/Digital_Fee_Payment/P_Add_Student.jsp?sid="+id+"'>Click Here to add student.</a><br><br></td></tr><tr><td colspan='2'>Thanking You</td></tr>" ,"text/html; charset=utf-8" );
				multipart.addBodyPart(messageBodyPart3);  
				message.setContent(multipart );           			    
				Transport.send(message);
			} catch (Exception e) {
				
				e.printStackTrace();
			}
		      }
		
	}
		

}
