package beans;
/**
 * @author Sathyajith P S
 * POJO class for getting and setting error header, body, url and status details for settings,index,fees and students page
 */
public class Error {
	private String header;
	private String body;
	private String url;
	private boolean response;
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public boolean isResponse() {
		return response;
	}
	public void setResponse(boolean response) {
		this.response = response;
	}
	
}
