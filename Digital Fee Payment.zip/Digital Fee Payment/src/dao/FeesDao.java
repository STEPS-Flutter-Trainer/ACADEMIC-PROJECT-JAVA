package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beans.Fees;

import dB.Dbb;

/**
 * @author Sathyajith P S
 * Fees data access object for getting list of fees, get  fees by id and update fee by id. Used in fees related pages
 */
public class FeesDao {
	
	public static List<Fees> getFeeList(String email){ 
		//System.out.println("Started fetching fee List");
		//System.out.println("Creating Database Connection");
		Dbb db = new Dbb();
		//System.out.println("Successfully connected to database");
		List<Fees> fee_list=new ArrayList<Fees>();
		//System.out.println("Creating list object for fees");
	    try{  
	    	//System.out.println("Preparing Query");
	        String  sql = "SELECT fee.fee_id,student.Student_id,student.Student_course,student.Student_name,fee.fee_amount,fee.fee_due FROM student INNER JOIN fee ON student.Student_pid=fee.Student_id RIGHT JOIN school ON student.Sch_id=school.Sch_id WHERE school.Sch_email =?";
	        PreparedStatement fetch_student_data = db.getPreparedstatement(sql);
	      //System.out.println("Setting values to query");
	        fetch_student_data.setString(1, email );
	      //System.out.println("Fetching resultset");
	        ResultSet student_data = fetch_student_data.executeQuery();
	        //System.out.println("Result set fetched");
	        while(student_data.next()){
	        	Fees u = new Fees();
	        	u.setPid(student_data.getInt("fee_id"));
	        	u.setRollNo(student_data.getInt("Student_id"));
	        	u.setCourse(student_data.getString("Student_course"));
	        	u.setName(student_data.getString("Student_name"));
	        	u.setAmount(student_data.getFloat("fee_amount"));
	        	u.setDue(student_data.getDate("fee_due"));
	        	fee_list.add(u);
	        }
	    }catch(Exception e){System.out.println(e);}  
	    //System.out.println("Sending fee list");
	    return fee_list;
	    //System.out.println("Fee list sent");
	}
	
	public static Fees getFeeById(int pid) throws SQLException {
		//System.out.println("Started fetching fee by id");
		//System.out.println("Creating Database Connection");
		Fees u = null;
		Dbb db = new Dbb();
		//System.out.println("Successfully connected to database");
		//System.out.println("Preparing Query");
		String sql = "SELECT fee.fee_amount,fee.fee_due,student.Student_name FROM fee,student WHERE fee_id=? AND fee.Student_id=student.Student_pid";
		PreparedStatement get_fee = db.getPreparedstatement(sql);
		//System.out.println("Setting values to query");
		get_fee.setInt(1, pid);
		//System.out.println("Fetching resultset");
		ResultSet fee = get_fee.executeQuery();
		 //System.out.println("Result set fetched");
		while(fee.next()) {
			u = new Fees();
			u.setName(fee.getString("Student_name"));
			u.setAmount(fee.getFloat("fee_amount"));
			u.setDue(fee.getDate("fee_due"));
			
		}
		 //System.out.println("Sending fetched fee");
		return u;
		//System.out.println("Fetched fee sent");
	}
	
	public static void updateFees(int id,float amount,java.sql.Date due) throws SQLException {
		//System.out.println("Started updating fee List");
		//System.out.println("Creating Database Connection");
		Dbb db = new Dbb();
		//System.out.println("Created Database Connection");
		//System.out.println("Preparing Query");
		String sql = "INSERT INTO fee (fee_id,fee_amount,fee_due ) VALUES (?,?,?) ON DUPLICATE KEY UPDATE fee_amount = ?,fee_due = ?";
		PreparedStatement update_fee = db.getPreparedstatement(sql);
		//System.out.println("Setting values to Query");
		update_fee.setInt(1, id);
		update_fee.setFloat(2, amount);
		update_fee.setDate(3, (java.sql.Date) due);
		update_fee.setFloat(4, amount);
		update_fee.setDate(5,(java.sql.Date) due);
		//System.out.println("Executing query");
		update_fee.executeUpdate();
		//System.out.println("Query executed");
	}
}
