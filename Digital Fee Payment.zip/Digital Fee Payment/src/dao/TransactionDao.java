package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beans.Transaction;
import dB.Dbb;

/**
 * @author Sathyajith P S
 * TransactionDao fetches transaction list form transaction table to payment.jsp
 */
public class TransactionDao {
 public static List<Transaction> getTransactions(String email) throws SQLException {
	 //System.out.println("Started getting transaction list");
	//System.out.println("Creating transaction list object");
	 List<Transaction> payment_history_list=new ArrayList<Transaction>();
	//System.out.println("Creating database connection");
	 Dbb db = new Dbb();
	//System.out.println("Database connection created");
	//System.out.println("Preparing query for getting school id");
	 String sql = "SELECT Sch_id FROM school WHERE Sch_email = ? ";
	 PreparedStatement get_sch_id = db.getPreparedstatement(sql);
	//System.out.println("Setting values for fetching school id");
	 get_sch_id.setString(1, email);
	//System.out.println("Fetching resultset for school id");
	 ResultSet sch_id = get_sch_id.executeQuery();
	//System.out.println("Resultset fetched");
	 while(sch_id.next()) {
		 int id = sch_id.getInt("Sch_id");
		//System.out.println("School ID saved to id");
		//System.out.println("Preparing query for fetching transaction list");
		 String sql_1 = "SELECT student.Student_id,student.Student_course,student.Student_name,parent.Par_name,transaction.fee_amount,transaction.fee_due,transaction.Trans_date FROM student INNER JOIN project.transaction ON transaction.student_id = student.Student_pid INNER JOIN parent ON student.Par_id = parent.Par_id WHERE student.Sch_id =?";
		 PreparedStatement fetch_payment_history = db.getPreparedstatement(sql_1);
		//System.out.println("Setting values for query");
		 fetch_payment_history.setInt(1, id);
		//System.out.println("Fetching Resultset");
		 ResultSet payment_history = fetch_payment_history.executeQuery();
		//System.out.println("ResultSet fetched");
		 while(payment_history.next()) {
			 Transaction u = new Transaction();
			 u.setRollno(payment_history.getInt("Student_id"));
			 u.setCourse(payment_history.getString("Student_course"));
			 u.setName(payment_history.getString("Student_name"));
			 u.setParent(payment_history.getString("Par_name"));
			 u.setAmount(payment_history.getFloat("fee_amount"));
			 u.setDue((java.sql.Date) payment_history.getDate("fee_due"));
			 u.setPaid((java.sql.Date) payment_history.getDate("Trans_date"));
			 payment_history_list.add(u);
		 }
		 
	 }
	//System.out.println("Sending Result Set");
	return payment_history_list;
	//System.out.println("Result Set sent");
 }
}
