package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.mail.MessagingException;
import beans.Students;
import dB.Dbb;
import mail.Mail;

/**
 * @author Sathyajith P S
 * StudentDao is used to fetch students as list or by id, edit or add existing/new student. Used in students section.
 */
public class StudentDao {
	
	
	public static List<Students> getStudentList(String email){ 
		//System.out.println("Started fetching student list");
		//System.out.println("Creating Database connection");
		Dbb db = new Dbb();
		//System.out.println("creating list object for students");
		List<Students> student_list=new ArrayList<Students>(); 
		//System.out.println("List object created");
	    try{  
	    	//System.out.println("Preparing query");
	        String  sql = "SELECT student.Student_pid,student.Student_id,student.Student_name,student.Student_course,parent.Par_name,student.Student_email,student.Student_status FROM student INNER JOIN parent ON student.Par_id = parent.Par_id RIGHT JOIN school ON student.Sch_id=school.Sch_id WHERE Sch_email = ?";
	        PreparedStatement fetch_student_data = db.getPreparedstatement(sql);
	      //System.out.println("Setting values to query");
	        fetch_student_data.setString(1, email );
	      //System.out.println("Fetching resultset");
	        ResultSet student_data = fetch_student_data.executeQuery();
	      //System.out.println("ResultSet fetched");
	        while(student_data.next()){
	        	Students u = new Students();
	        	u.setPid(student_data.getInt("Student_pid"));
	        	u.setRollNo(student_data.getInt("Student_id"));
	        	u.setCourse(student_data.getString("Student_course"));
	        	u.setName(student_data.getString("Student_name"));
	        	u.setParent(student_data.getString("Par_name"));
	        	u.setEmail(student_data.getString("Student_email"));
	        	u.setStatus(student_data.getInt("Student_status"));
	        	student_list.add(u);
	        }
	    }catch(Exception e){System.out.println(e);}  
	    //System.out.println("Sending student list");
	    return student_list;
	  //System.out.println("Student list sent");
	}
	
	public static Students getStudentById(int pid) throws SQLException {
		//System.out.println("Started fetching student by id");
		//System.out.println("Creating Database connection");
		Students u = null;
		Dbb db = new Dbb();
		//System.out.println("Created Database connection");
		//System.out.println("Preparing Query");
		String sql = "SELECT * FROM student WHERE student.Student_pid = ?";
		PreparedStatement get_student = db.getPreparedstatement(sql);
		//System.out.println("Setting values to query");
		get_student.setInt(1, pid);
		//System.out.println("Fetching resultset");
		ResultSet student = get_student.executeQuery();
		//System.out.println("Resultset fetched");
		while(student.next()) {
			u = new Students();
			u.setName(student.getString("Student_name"));
			u.setRollNo(student.getInt("Student_id"));
			u.setCourse(student.getString("Student_course"));
			u.setStatus(student.getInt("Student_status"));
			u.setParentid(student.getInt("Par_id"));
			u.setSchoolid(student.getInt("Sch_id"));
			u.setEmail(student.getString("Student_Email"));
		}
		//System.out.println("Sending fetched student");
		return u;
		//System.out.println("Fetched student sent");
	}
	
	public static void updateStudent(int pid, int id, String name, int status, String course, int sid, int paid) throws SQLException {
		//System.out.println("Started updating student by id");
		//System.out.println("Creating Database connection");
		Dbb db = new Dbb();
		//System.out.println("Database connection created");
		//System.out.println("Preparing query");
		String sql = "UPDATE student SET Student_name =?,Student_course=?,Student_id=?,Student_status=? WHERE Sch_id=? AND Student_pid =?";
		PreparedStatement update_student = db.getPreparedstatement(sql);
		//System.out.println("Setting values to query");
		update_student.setString(1, name);
		update_student.setString(2,course);
		update_student.setInt(3, id);
		update_student.setInt(4, status);
		update_student.setInt(5, sid);
		update_student.setInt(6, pid);
		//System.out.println("Executing query");
		update_student.executeUpdate();
		//System.out.println("Query executed");
	}
	public static void addStudent(int id, String name, String course, int status, String email,String user) throws SQLException {
		//System.out.println("Started adding student");
		//System.out.println("Creating Database connection");
		Dbb db = new Dbb();
		//System.out.println("Database connection created");
		int sc_id=0;
		//System.out.println("Preparing query for fetching school id");
		String sql_id="SELECT Sch_id FROM project.school WHERE Sch_email=?";
		PreparedStatement get_sch_id = db.getPreparedstatement(sql_id);
		//System.out.println("Setting values for fetching school id");
		get_sch_id.setString(1, user);
		//System.out.println("Fetching resultset for school id");
		ResultSet fetched_id = get_sch_id.executeQuery();
		//System.out.println("Resultset fetched");
		while(fetched_id.next()) {
			sc_id = fetched_id.getInt("Sch_id");
			//System.out.println("School ID saved to sc_id");
		}
		//System.out.println("Preparing query for Inserting student");
		String sql = "INSERT INTO student (Student_id,Student_name,Student_course,Student_email,Student_status,Sch_id,Par_id) VALUES(?,?,?,?,?,?,?)";
		PreparedStatement add_student = db.getPreparedstatement(sql);
		//System.out.println("Setting values for inserting student");
		add_student.setInt(1, id);
		add_student.setString(2, name);
		add_student.setString(3, course);
		add_student.setString(4, email);
		add_student.setInt(5, 1);
		add_student.setInt(6, sc_id);
		add_student.setInt(7, 2);
		//System.out.println("Executing query");
		add_student.execute();
		//System.out.println("Student Inserted");
		//System.out.println("Preparing query to fetch student ID");
		String sql_1 = "SELECT Student_pid FROM student WHERE Student_name=? and Student_Email=?";
		PreparedStatement student_id_retrieve = db.getPreparedstatement(sql_1);
		//System.out.println("Setting values to query");
		student_id_retrieve.setString(1, name);
		student_id_retrieve.setString(2, email);
		//System.out.println("Fetching result");
		ResultSet student_id = student_id_retrieve.executeQuery();
		//System.out.println("Result fetched");
		while (student_id.next()) {
			int retrieved_id = student_id.getInt(1);
			//System.out.println("Student ID saved to retrieved_id");
			//System.out.println("Preparing query for inserting student corresponding row to fee table");
			String sql_2 = "INSERT INTO fee(Student_id) VALUES (?)";
			PreparedStatement student_id_insert = db.getPreparedstatement(sql_2);
			//System.out.println("Setting values to query");
			student_id_insert.setInt(1, retrieved_id);
			//System.out.println("Executing query");
			student_id_insert.executeUpdate();
			//System.out.println("Executed query");
			try {
				//System.out.println("Sending mail to entered mail");
				Mail.sendParentMail(email,name,retrieved_id);
			} catch (MessagingException e) {
				//System.out.println("Messaging exception");
				e.printStackTrace();
			} catch (Exception e) {
				//System.out.println("Exception");
				e.printStackTrace();
			}
		}
	}
}
