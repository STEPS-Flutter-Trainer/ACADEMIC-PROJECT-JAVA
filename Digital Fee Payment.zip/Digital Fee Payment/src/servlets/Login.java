package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import validations.LoginValidation;


@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			
			/* Parameters from index.jsp - email and pass is fetched and saved to the strings.
			 * After Validation, the responses are sent out as JSON objects.
			 */
			
			String username = request.getParameter("email");
			String pass = request.getParameter("pass");
			String userValidate = LoginValidation.validate(username, pass);
			

			if (userValidate.equals("superadmin")) {
				
				HttpSession session = request.getSession();
					session.setMaxInactiveInterval(5 * 60);
					session.setAttribute("mailid", username);
					
				beans.Error e = new beans.Error();
					e.setUrl("sahome.jsp");
					
				Gson gson = new Gson();
					String json_response = gson.toJson(e);
					
				response.setContentType("text/plain");  
			    response.setCharacterEncoding("UTF-8");
			    response.getWriter().write(json_response);
			    
			} else if (userValidate.equals("admin")) {
				
				HttpSession session = request.getSession();
					session.setMaxInactiveInterval(5 * 60);
					session.setAttribute("name", username);
				
				beans.Error e = new beans.Error();
					e.setUrl("ahome.jsp");
				
				Gson gson = new Gson();
					String json_response = gson.toJson(e);
				
				response.setContentType("text/plain");  
			    response.setCharacterEncoding("UTF-8");
			    response.getWriter().write(json_response);

			} else if (userValidate.equals("school")) {
				
				HttpSession session = request.getSession();
					session.setMaxInactiveInterval(5 * 60);
					session.setAttribute("school", username);
				
				beans.Error e = new beans.Error();
					e.setUrl("school_home.jsp");
				
				Gson gson = new Gson();
					String json_response = gson.toJson(e);
				
				response.setContentType("text/plain");  
			    response.setCharacterEncoding("UTF-8");
			    response.getWriter().write(json_response);
			} else if (userValidate.equals("parent")) {
				
				HttpSession session = request.getSession();
					session.setMaxInactiveInterval(5 * 60);
					session.setAttribute("parent", username);
				
				beans.Error e = new beans.Error();
					e.setUrl("Parent_Home_Page.jsp");
				
				Gson gson = new Gson();
					String json_response = gson.toJson(e);
				
				response.setContentType("text/plain");  
			    response.setCharacterEncoding("UTF-8");
			    response.getWriter().write(json_response);
			}else if (userValidate.equals("inactive")) {
				
				beans.Error e = new beans.Error();
					e.setHeader("Inactive Account");
					e.setBody("Your account is inactive, contact Admin !");
					e.setUrl("");
					
				Gson gson = new Gson();
					String json_response = gson.toJson(e);
				
				response.setContentType("text/plain");  
			    response.setCharacterEncoding("UTF-8");
			    response.getWriter().write(json_response);
			} else {
				
				beans.Error e = new beans.Error();
					e.setHeader("Invalid Credentials");
					e.setBody("Email or Password Error");
					e.setUrl("");
					
				Gson gson = new Gson();
					String json_response = gson.toJson(e);
					
				response.setContentType("text/plain");  
			    response.setCharacterEncoding("UTF-8");
			    response.getWriter().write(json_response);
		}
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (Exception e2) {
			e2.printStackTrace();
		}
	}

}
