package servlets;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import beans.SHome;
import dB.Dbb;

@WebServlet("/SchoolHome")
public class SchoolHome extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
		String email = (String) request.getSession().getAttribute("school");
		Dbb db = new Dbb();
		SHome s = new SHome();
		
		String sql="SELECT Sch_id FROM project.school WHERE Sch_email=?";
		PreparedStatement get_sch_id = db.getPreparedstatement(sql);
		get_sch_id.setString(1, email);
		ResultSet fetched_id = get_sch_id.executeQuery();
		while(fetched_id.next()) {
			int id = fetched_id.getInt("Sch_id");
			
			String sql_1 = "SELECT COUNT( DISTINCT(Par_id) ) FROM project.student WHERE Sch_id =?";
			PreparedStatement parent_count = db.getPreparedstatement(sql_1);
			parent_count.setInt(1, id);
			ResultSet p_count = parent_count.executeQuery();
			while(p_count.next()) {
				s.setParents(String.valueOf(p_count.getInt(1)));
			}
			
			String sql_2 = "SELECT COUNT(student.Student_pid) FROM project.student WHERE Sch_id =?";
			PreparedStatement student_count = db.getPreparedstatement(sql_2);
			student_count.setInt(1, id);
			ResultSet s_count = student_count.executeQuery();
			while(s_count.next()) {
				s.setStudents(String.valueOf(s_count.getInt(1)));
			}
			
			String sql_3 = "SELECT COUNT(transaction.Trans_id) FROM project.transaction INNER JOIN student ON transaction.student_id = student.Student_pid WHERE Sch_id =?";
			PreparedStatement transaction_count = db.getPreparedstatement(sql_3);
			transaction_count.setInt(1, id);
			ResultSet tl_count = transaction_count.executeQuery();
			while(tl_count.next()) {
				s.setTransaction(String.valueOf(tl_count.getInt(1)));
			}
			
			String sql_4 = "SELECT ROUND(SUM(transaction.fee_amount),2) FROM project.transaction INNER JOIN student ON transaction.student_id = student.Student_pid WHERE Sch_id =?";
			PreparedStatement fee_count = db.getPreparedstatement(sql_4);
			fee_count.setInt(1, id);
			ResultSet f_count = fee_count.executeQuery();
			while(f_count.next()) {
				s.setFees(String.valueOf(f_count.getFloat(1)));
			}
			
			String sql_5 = "SELECT COUNT(issue.issue_status) FROM project.issue WHERE issue.issue_raiser = ? AND issue.issue_status=1";
			PreparedStatement solved_count = db.getPreparedstatement(sql_5);
			solved_count.setString(1, email);
			ResultSet so_count = solved_count.executeQuery();
			while(so_count.next()) {
				s.setSolved(String.valueOf(so_count.getInt(1)));
			
			}
			
			String sql_6 = "SELECT COUNT(issue.issue_status) FROM project.issue WHERE issue.issue_raiser = ? AND issue.issue_status=0";
			PreparedStatement issue_count = db.getPreparedstatement(sql_6);
			issue_count.setString(1, email);
			ResultSet i_count = issue_count.executeQuery();
			while(i_count.next()) {
				s.setIssues(String.valueOf(i_count.getInt(1)));
			}
		}
		Gson gson = new Gson();
		String json_response = gson.toJson(s);
		response.setContentType("text/plain");  
	    response.setCharacterEncoding("UTF-8");
	    response.getWriter().write(json_response);
			/* System.out.println(json_response); */
		}catch(Exception e) {
			
		}
		
	}

}
