package servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import dao.StudentDao;

@WebServlet("/AddStudent")
public class AddStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("mail");
		int id = Integer.valueOf(request.getParameter("roll"));
		String name = request.getParameter("name");
		String course = request.getParameter("course");
		int status = Integer.valueOf(request.getParameter("status"));
		String user = (String) request.getSession().getAttribute("school");
		try {
			StudentDao.addStudent(id, name, course, status, email,user);
			beans.Error e = new beans.Error();
			e.setHeader("Success");
			e.setBody("Student Added");
			e.setResponse(true);
			Gson gson = new Gson();
			String json_response = gson.toJson(e);
			 response.setContentType("text/plain");  
			 response.setCharacterEncoding("UTF-8");
			 response.getWriter().write(json_response);
		} catch (SQLException e) {
			beans.Error s = new beans.Error();
			s.setHeader("Error");
			s.setBody("Could not Add Student");
			s.setResponse(true);
			Gson gson = new Gson();
			String json_response = gson.toJson(s);
			 response.setContentType("text/plain");  
			 response.setCharacterEncoding("UTF-8");
			 response.getWriter().write(json_response);
			e.printStackTrace();
		}
	}

}
