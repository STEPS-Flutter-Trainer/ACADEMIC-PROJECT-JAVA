package servlets;

import java.io.IOException;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import dB.Dbb;

@WebServlet("/CreateIssue")
public class CreateIssue extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Dbb db = new Dbb();
			String title = request.getParameter("title");
			String content = request.getParameter("content");
			String email = (String) request.getSession().getAttribute("school");
			if(title == "" || title == null) {
				beans.Error s = new beans.Error();
				s.setHeader("Title cannot be empty");
				Gson gson = new Gson();
				String json_response = gson.toJson(s);
				 response.setContentType("text/plain");  
				 response.setCharacterEncoding("UTF-8");
				 response.getWriter().write(json_response);
			}else if(content == "" || content == null) {
				beans.Error s = new beans.Error();
				s.setHeader("Issue description cannot be empty");
				Gson gson = new Gson();
				String json_response = gson.toJson(s);
				 response.setContentType("text/plain");  
				 response.setCharacterEncoding("UTF-8");
				 response.getWriter().write(json_response);
			}else {
				String sql = "INSERT INTO issue (issue_raiser,issue_title,issue_content) VALUES (?,?,?)";
				PreparedStatement insert_into_issue = db.getPreparedstatement(sql);
				insert_into_issue.setString(1, email);
				insert_into_issue.setString(2, title);
				insert_into_issue.setString(3, content);
				insert_into_issue.executeUpdate();
				beans.Error s = new beans.Error();
				s.setHeader("Issue Created");
				Gson gson = new Gson();
				String json_response = gson.toJson(s);
				 response.setContentType("text/plain");  
				 response.setCharacterEncoding("UTF-8");
				 response.getWriter().write(json_response);
			}
		} catch (Exception e) {
			beans.Error s = new beans.Error();
			s.setHeader("Error while creating Issue");
			Gson gson = new Gson();
			String json_response = gson.toJson(s);
			 response.setContentType("text/plain");  
			 response.setCharacterEncoding("UTF-8");
			 response.getWriter().write(json_response);
			e.printStackTrace();
		}
	}

}
