package servlets;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import dB.Dbb;

@WebServlet("/ChangePassword")
public class ChangePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Dbb db = new Dbb();
		int i = 0;
		

//CHANGE PASSWORD

		String email_id = (String) request.getSession().getAttribute("school");
		String current_password = null, current_key = null;
		ResultSet passwordResult = null;

//FETCHING LOGIN PASSWORD AND KEY

		String Query = "select Lo_password, Lo_key from login_table where Lo_username=?";

		PreparedStatement p;
		try {
			p = db.getPreparedstatement(Query);
			p.setString(1, email_id);
			passwordResult = p.executeQuery();
			while (passwordResult.next()) {
				current_password = passwordResult.getString(1);
				current_key = passwordResult.getString(2);
			}
		} catch (SQLException e1) {
			beans.Error s = new beans.Error();
			s.setHeader("Could not update password");
			s.setResponse(false);
			s.setUrl("");
			Gson gson = new Gson();
			String json_response = gson.toJson(s);
			 response.setContentType("text/plain");  
			 response.setCharacterEncoding("UTF-8");
			 response.getWriter().write(json_response);
			e1.printStackTrace();
		}
		

		String pass_current = request.getParameter("current");
		String pass_new = request.getParameter("newpass");
		String pass_confirm = request.getParameter("confirm");

//SALTING PASSWORD

		String ch_pass = pass_current + current_key;
		String ch_enc_pass = Base64.getEncoder().encodeToString(ch_pass.getBytes("utf-8"));
		if(!ch_enc_pass.equals(current_password)) {	
			beans.Error s = new beans.Error();
			s.setHeader("Entered password doesn't match with existing password");
			s.setResponse(false);
			s.setUrl("");
			Gson gson = new Gson();
			String json_response = gson.toJson(s);
			 response.setContentType("text/plain");  
			 response.setCharacterEncoding("UTF-8");
			 response.getWriter().write(json_response);
		}else if(!pass_confirm.equals(pass_new)) {
			beans.Error s = new beans.Error();
			s.setHeader("Entered password doesn't match");
			s.setResponse(false);
			s.setUrl("");
			Gson gson = new Gson();
			String json_response = gson.toJson(s);
			 response.setContentType("text/plain");  
			 response.setCharacterEncoding("UTF-8");
			 response.getWriter().write(json_response);
		}else if (pass_confirm.equals(pass_new) && ch_enc_pass.equals(current_password)) {
			try {
			String passUpdt = "UPDATE login_table SET Lo_password=? WHERE Lo_username=?";
			String new_ch_pass = pass_new + current_key;
			String new_enc_pass = Base64.getEncoder().encodeToString(new_ch_pass.getBytes("utf-8"));
			PreparedStatement updated_pass = db.getPreparedstatement(passUpdt);
				updated_pass.setString(1, new_enc_pass);
				updated_pass.setString(2, email_id);
				i = updated_pass.executeUpdate();
				if (i > 0) {
					beans.Error s = new beans.Error();
					s.setHeader("Password Changed");
					s.setResponse(true);
					s.setUrl("logout.jsp");
					Gson gson = new Gson();
					String json_response = gson.toJson(s);
					 response.setContentType("text/plain");  
					 response.setCharacterEncoding("UTF-8");
					 response.getWriter().write(json_response);
				}
			} catch (SQLException e) {
				beans.Error s = new beans.Error();
				s.setHeader("Could not update password");
				s.setResponse(false);
				s.setUrl("");
				Gson gson = new Gson();
				String json_response = gson.toJson(s);
				 response.setContentType("text/plain");  
				 response.setCharacterEncoding("UTF-8");
				 response.getWriter().write(json_response);
			}
		}
		
	}

}
