package servlets;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.apache.tika.Tika;

import com.google.gson.Gson;

import excel_operations.Student;

@WebServlet("/FeeUpload")
public class FeeUpload extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (ServletFileUpload.isMultipartContent(request)) {
			try {
				List<FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);

				final String root = System.getProperty("user.home");
				final String parent_path = File.separator+"ExcelFiles"+File.separator;
				String user = (String) request.getSession().getAttribute("school");
				String user_path = user+File.separator;
				final String upload_directory = root + parent_path + user_path;

				for (FileItem item : multiparts) {
					if (!item.isFormField()) {
						File fileSaveDirectory = new File(upload_directory);
						if (!fileSaveDirectory.exists()) {
							fileSaveDirectory.mkdirs();
						}
						String name = new File(item.getName()).getName();

						item.write(new File(upload_directory + File.separator + name));
						
						/*
						 * Following Code checks the filetype using Apache Tika API
						 * If the file type is a mismatch, the user path is deleted.
						 * The parent path is permanent and doesn't get deleted
						 * */
						
						Tika tika = new Tika();
						String type = tika.detect(new File(upload_directory + File.separator + name));
						// System.out.println("file type : " + type);
						String required_filetype = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

						if (type.equals(required_filetype)) {
							Student studentUpload = new Student();
							studentUpload.ImportFee(upload_directory + File.separator + name);
							FileUtils.deleteDirectory(new File(upload_directory));
							beans.Error e = new beans.Error();
							e.setHeader("Success");
							e.setBody("File was uploaded. Refresh the page to see the data.");
							e.setResponse(true);
							Gson gson = new Gson();
							String json_response = gson.toJson(e);
							 response.setContentType("text/plain");  
							 response.setCharacterEncoding("UTF-8");
							 response.getWriter().write(json_response);
							// System.out.println("Correct file type");
						} else {
							// System.out.println("Incorrect file type");
							// System.out.println("Deleting Directory");
							FileUtils.deleteDirectory(new File(upload_directory));
							beans.Error e = new beans.Error();
							e.setHeader("Incorrect File Type");
							e.setBody("The file uploaded is note a proper xlsx file, please upload a valid xlsx file. Try renaming the file. If the file still doesn't upload disable all filters, styles, additional script or sheets in the workbook and try again");
							e.setResponse(true);
							Gson gson = new Gson();
							String json_response = gson.toJson(e);
							response.setContentType("text/plain");  
							 response.setCharacterEncoding("UTF-8");
							 response.getWriter().write(json_response);
						}
					}
				}
			} catch (Exception e) {

			}

			
		}

	}

}