package servlets;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import org.apache.commons.io.FileUtils;

import excel_operations.Student;
@WebServlet("/FeeDownload")
public class FeeDownload extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		final String root = System.getProperty("user.home");
		final String parent_path = File.separator+"ExcelFiles"+File.separator;
		String user = (String) request.getSession().getAttribute("school");
		String user_path = user+File.separator;
		String filename = "Fees.xlsx";
		final String download_directory = root + parent_path + user_path;
		File fileSaveDirectory = new File(download_directory);
		if (!fileSaveDirectory.exists()) {
			fileSaveDirectory.mkdirs();
		}
		
		Student fee_generator = new Student();
		try {
			fee_generator.ExportFee(download_directory,user);
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + filename + "\"");

		FileInputStream fileInputStream = new FileInputStream(download_directory + filename);

		int i;
		while ((i = fileInputStream.read()) != -1) {
			out.write(i);
		}
		fileInputStream.close();
		out.close();
		
		FileUtils.deleteDirectory(new File(download_directory));
	}

}
