package servlets;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import dB.Dbb;

@WebServlet("/ChangeANET")
public class ChangeANET extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
		Dbb db = new Dbb();
		String fetched_loginid =null;
		String fetched_trnkey = null;
		String email=(String) request.getSession().getAttribute("school");
		String sql= "SELECT Sch_api_loginid, Sch_api_trnkey FROM school WHERE Sch_email=?";
		PreparedStatement fetch_loginid_and_transactionkey = db.getPreparedstatement(sql);
		fetch_loginid_and_transactionkey.setString(1, email);
		ResultSet loginid_and_transactionkey = fetch_loginid_and_transactionkey.executeQuery();

		while(loginid_and_transactionkey.next()){
			fetched_loginid = loginid_and_transactionkey.getString("Sch_api_loginid");
			fetched_trnkey = loginid_and_transactionkey.getString("Sch_api_trnkey");
			
			String entered_loginid = request.getParameter("current_api");
			String entered_trnkey = request.getParameter("current_trn");
			String new_loginid = request.getParameter("new_api");
			String new_trnkey= request.getParameter("new_trn");
			String new_loginid_confirm = request.getParameter("new_api_confirm");
			String new_trnkey_confirm = request.getParameter("new_trn_confirm");
			
			if(!entered_loginid.equals(fetched_loginid)) {
				beans.Error s = new beans.Error();
				s.setHeader("Enter the correct API Login ID");
				Gson gson = new Gson();
				String json_response = gson.toJson(s);
				 response.setContentType("text/plain");  
				 response.setCharacterEncoding("UTF-8");
				 response.getWriter().write(json_response);
			}else if(!entered_trnkey.equals(fetched_trnkey)) {
				beans.Error s = new beans.Error();
				s.setHeader("Enter the correct Transaction Key");
				Gson gson = new Gson();
				String json_response = gson.toJson(s);
				 response.setContentType("text/plain");  
				 response.setCharacterEncoding("UTF-8");
				 response.getWriter().write(json_response);
			}else if(!new_loginid.equals(new_loginid_confirm)) {
				beans.Error s = new beans.Error();
				s.setHeader("New API Login ID and confirmed API Login ID doesn't match");
				Gson gson = new Gson();
				String json_response = gson.toJson(s);
				 response.setContentType("text/plain");  
				 response.setCharacterEncoding("UTF-8");
				 response.getWriter().write(json_response);
			}else if(!new_trnkey.equals(new_trnkey_confirm)) {
				beans.Error s = new beans.Error();
				s.setHeader("New Transaction Key and confirmed Transaction Key doesn't match");
				Gson gson = new Gson();
				String json_response = gson.toJson(s);
				 response.setContentType("text/plain");  
				 response.setCharacterEncoding("UTF-8");
				 response.getWriter().write(json_response);
			}else {
				String sql_1 = "UPDATE school SET Sch_api_loginid = ? , Sch_api_trnkey = ? WHERE Sch_email=?";
				PreparedStatement insert_loginid_and_transactionkey = db.getPreparedstatement(sql_1);
				insert_loginid_and_transactionkey.setString(1, new_loginid);
				insert_loginid_and_transactionkey.setString(2, new_trnkey);
				insert_loginid_and_transactionkey.setString(3, email);
				insert_loginid_and_transactionkey.executeUpdate();
				beans.Error s = new beans.Error();
				s.setHeader("API Login ID and Transaction Key updated !");
				s.setUrl("school_settings.jsp");
				Gson gson = new Gson();
				String json_response = gson.toJson(s);
				 response.setContentType("text/plain");  
				 response.setCharacterEncoding("UTF-8");
				 response.getWriter().write(json_response);
			}
			
		}


	}catch (Exception e) {
		beans.Error s = new beans.Error();
		s.setHeader("Could Not Update");
		Gson gson = new Gson();
		String json_response = gson.toJson(s);
		 response.setContentType("text/plain");  
		 response.setCharacterEncoding("UTF-8");
		 response.getWriter().write(json_response);
		e.printStackTrace();
	}

}
}
